(function () {
    var $dialog = $.pdialog.getCurrent();
//    alert($dialog.html());
    setTimeout(function () {
        $('#sqss', $dialog).click();
    }, 0);
}).call();

