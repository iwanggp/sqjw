(function () {
    var $page = navTab.getCurrentPanel();
//    setTimeout(function () {
//        $('#bgjd', $page).click();
//    }, 0);

}).call();